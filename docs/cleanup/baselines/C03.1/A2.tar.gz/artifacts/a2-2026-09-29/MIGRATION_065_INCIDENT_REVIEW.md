# Migration 065 incident review — 29 September 2026

## Finding and cause

Migration `065_exchange_source_access.sql` was applied to the live local SQLite
database at **2026-09-29 09:29:23.883230 UTC** without an approved deployment.
The migration file was briefly placed in the host `scrapper/db/migrations/`
directory during A2 development. The running Compose services bind mount that
host directory at `/app/scrapper` (usually container-read-only), while `/data`
is a writable production database volume. A host file edit is immediately
visible through a read-only container bind mount.

Routine worker paths call `init_db()`; its current implementation scans every
`*.sql` migration at each call and applies any filename absent from
`schema_migrations`. It has no production approval gate. The scheduler, daemon,
document, and other worker paths all contain normal `init_db()` calls. The
application did not log which process acquired the migration lock at 09:29:23,
so the exact worker cannot be established from available evidence. The
automatic migration mechanism, rather than a deliberate `init-db` invocation,
explains how a visible review file was applied.

The mounted source files were restored immediately. Current inspection found
the 065 file **absent** from `/app/scrapper/db/migrations/` and no A2 code change
in the active `scrapper/` checkout. No service was restarted and no live source
request was made during this review.

## What migration 065 changed

The SQL rebuilt `exchange_schedule_runs` with its existing columns, uniqueness
key and indexes, adding `source_access_blocked` to the allowed outcomes. It
created `exchange_source_access_events` plus an index, then inserted one
`BLOCKED` event for each BSE dataset whose last real recorded fetch was an HTTP
403. It did not modify result watermarks, accepted page versions, source
snapshots, company queues, or financial values. No table has a declared foreign
key to `exchange_schedule_runs` in the pre-065 schema.

| Read-only evidence | Before (A0 backup, 64 migrations) | Post-065 backup |
|---|---:|---:|
| Applied migrations | 64 | **65** |
| `exchange_schedule_runs` rows | 333 | **333** |
| Schedule-row SHA256, ordered by `schedule_run_id` | `d45883e51e43444e6cfdc4ad1620a7ff3ca930a86e0aaa6971ea923327a7ebc5` | **same** |
| Exchange source snapshots | 236 | **236** |
| Accepted page versions | 7,199 | **7,199** |
| Result watermarks | 2 | **2** |
| Screener company queue rows | 12,746 | **12,746** |

The live read-only query and the new backup each showed exactly two backfilled
events: `bse_security_master` BLOCKED at **05:54:05 UTC**, and
`bse_financial_results` BLOCKED at **05:54:07 UTC**. Both carry evidence
`SOURCE_ACCESS_BLOCKED: prior scheduler HTTP 403`. The applied migration
version is `065_exchange_source_access.sql`. No `source_access_blocked`
schedule outcome was present in the still-running old application. The queue
had updates after the migration, demonstrating continued worker activity;
isolated old-code compatibility results are in
[PRODUCTION_COMPATIBILITY_TEST.md](PRODUCTION_COMPATIBILITY_TEST.md).

## New backup and restore verification

Using Python 3.12.14 SQLite `Connection.backup()` from a read-only connection
to `/data/scraper.db`, a new consistent backup was written to:

`/data/a2_post065_backup_20260929.sqlite` — **11,033,886,720 bytes**.

It was independently opened read-only: `PRAGMA quick_check = ok`, 65 applied
migrations, and the two expected events. A separate restore made with SQLite's
backup API at `/data/a2_post065_restore_verify_20260929.sqlite` had the same
byte size, 65 migrations, two events, and 333 schedule rows. Its full
`PRAGMA integrity_check = ok` (**348.99 seconds**). The untouched backup remains
separate from the disposable compatibility copies. The database lives in the
Docker named volume `trading-ai_scraper-data`; this is a consistent local
backup, not an offsite backup of the external document corpus.

## Containment and prevention

Until approved deployment, review changes remain under `a2-review/`, outside
the active source bind mount. The proposed [A2_REVIEW.patch](A2_REVIEW.patch)
adds two independent protections:

1. `init_db()` refuses a newly visible SQL migration on the configured service
   database during routine worker work; only the explicit `init-db
   --apply-migrations` path can apply it. Offline tests proved a new SQL file
   leaves the configured database and migration count unchanged.
2. The proposed Compose configuration removes all `/app/scrapper` host bind
   mounts. A dry-run `docker compose --profile '*' config` covered all **16**
   service definitions and found **zero** source-tree mounts. Running code then
   comes from a reviewed image, not mutable host files.

Neither protection is active in the running services. The current scheduler
container still has a read-only `/app/scrapper` bind from the mutable host and
a writable `/data` volume. Do not place review migrations in the active
`scrapper/` directory before the approved release. No automatic database
rollback is recommended: the old application is compatible with the expanded
schema, and dropping the new table or restoring A0 could lose later records.

## Limits

`PRAGMA integrity_check` passed on the new restore. A read-only
`PRAGMA foreign_key_check` on the live database returned violations in unrelated
queue-reference tables, and the pre-065 A0 backup also returned violations in
an unrelated queue-event table. A full before/after foreign-key count was not
completed; the migration SQL did not touch those tables. This incident review
does not claim the entire database is free of pre-existing referential issues.
