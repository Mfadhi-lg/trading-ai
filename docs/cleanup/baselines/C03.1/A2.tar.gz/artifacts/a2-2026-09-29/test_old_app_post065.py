"""Check the unpatched application against an isolated post-065 database copy."""

from __future__ import annotations

import json
import shutil
import sqlite3
import sys
from pathlib import Path

from scrapper.db.database import connect, init_db
from scrapper.db.exchange_repo import record_schedule_run
from scrapper.pipeline.scheduler import day_status


source = Path(sys.argv[1])
target = Path("/tmp/a2-old-app-compat.sqlite")
assert source.name == "a2_post065_backup_20260929.sqlite"
assert str(source).startswith("/source/")
assert not target.exists()
shutil.copyfile(source, target)
conn = connect(target)
try:
    before = conn.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0]
    assert before == 65
    init_db(conn)
    assert conn.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0] == before
    record_schedule_run(
        conn, dataset="nse_financial_results", scheduled_for="2026-09-30",
        attempt=1, role="primary", result_period="2026-06",
        outcome="fetch_failed", snapshot_id=None,
        error="isolated compatibility fixture", started_at_utc="2026-09-30T14:00:00+00:00",
        finished_at_utc="2026-09-30T14:00:01+00:00",
    )
    assert conn.execute(
        "SELECT outcome FROM exchange_schedule_runs WHERE scheduled_for='2026-09-30'"
    ).fetchone()[0] == "fetch_failed"
finally:
    conn.close()
status = day_status("2026-09-30", db_path=target)
assert any(row["outcome"] == "fetch_failed" for row in status["attempts"])
print(json.dumps({
    "result": "PASS", "python": sys.version.split()[0],
    "migrations_preserved": before,
    "legacy_ledger_write_on_copy": "PASS",
    "legacy_day_status_on_copy": "PASS",
    "source_volume_mount": "read_only", "network": "none",
}, sort_keys=True))
