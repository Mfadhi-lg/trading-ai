# A2 production compatibility test — 29 September 2026

**Result: PASS in isolation. No A2 application deployment was performed.**

## Environment reproduced

- Base: the existing scheduler image `trading-ai-scheduler:latest`, image ID
  `24efc027543a`, running **Python 3.12.14** on Linux ARM64.
- The current image lacks `pytest` and differs from `requirements.lock` on
  `charset-normalizer`, `playwright`, and `pypdfium2`. Six pinned Linux ARM64
  wheels were installed into `/private/tmp/trading-ai-a2-py312-deps`, outside
  the production image and containers. In the isolated test container, all
  **25/25** direct dependencies in `scrapper/requirements.lock` matched exactly.
- All test containers used `--network none`. The reviewed code and test scripts
  were bind mounted read-only. Where database access was needed, the Docker
  volume was mounted at `/source` **read-only**; scripts copied the post-065
  backup into the container's disposable `/tmp` before any application call.

## Offline suite

The exact contents of [A2_REVIEW.patch](A2_REVIEW.patch), represented in the
isolated `a2-review/` tree, were tested with pinned pytest 9.1.1:

| Tests | Result |
|---|---|
| Exchange universe, snapshot guard, dataset registry, scheduler, migration gate | **154 passed, 20 subtests passed** in 47.18 seconds |
| `git apply --check` against the active checkout | **PASS** |
| Proposed Compose config, all profiles | **16 services, zero `/app/scrapper` source mounts** |

The migration-gate test inserted a new review SQL file into a temporary
migration directory, called routine `init_db()` against the configured service
database, and verified that it raised before creating the proposed table or
changing the migration count. The explicit migration path worked on that
temporary database. No production database was used for that test.

## Database copy already at migration 065

[test_post065_copy.py](test_post065_copy.py) used a disposable copy of the new
post-065 backup. It checked 65 applied migrations and the two initial BSE
BLOCKED events, then injected only offline response fixtures:

| Scenario on copy | Observed result |
|---|---|
| Held BSE results and master at first and second scheduled rungs | **Zero BSE fetch calls**; `ACCESS_BLOCKED`, no false unpublished classification |
| Unrelated NSE result source | Primary/revision HTTP 404 fixtures ran; `ARTIFACT_NOT_FOUND`, then HTTP 500 became `FETCH_FAILED` and remained retryable |
| Existing alert path | `run_scheduler(once=True)` emitted structured JSON on stderr naming `bse_financial_results` |
| Controlled resume | Evidence-bearing resume made **zero** fetch calls; next permitted BSE fixture call occurred once and its 403 restored the hold |
| Data preservation | Accepted versions **7,199**, source snapshots **236**, result watermarks **2**, and company queue rows **12,746** were identical before and after; the watermark values were compared, not just counted |

Fixture request sequence: NSE 404, NSE revision 404, NSE 500, then BSE 403
after explicit resume. No real NSE or BSE request occurred.

## Currently running application on the changed schema

[test_old_app_post065.py](test_old_app_post065.py) loaded the unpatched
`scrapper/` source into a separate Python 3.12.14 container, copied the post-065
backup to disposable `/tmp`, and verified that legacy `init_db()` retained all
65 applied versions, a legacy `fetch_failed` ledger write succeeded under the
expanded table constraint, and legacy `day_status()` read it successfully.
The live old-code workers also continued to update queue records after the
migration. This establishes schema compatibility for the exercised legacy paths;
it does not prove every background path or future scheduled source run.

## Remaining limits

- The A2 patch, Compose mount removal and migration gate remain **review code**.
  The running application still has its mutable host-source bind mount and does
  not suppress BSE retries yet. Activation requires explicit deployment approval.
- The running image's dependency drift from `requirements.lock` was corrected
  only in disposable test containers, not in the production image. A release
  build must review and pin that choice.
- A2 did not test authorized live source access; the stored BSE HTTP 403 and
  source-entitlement uncertainty remain.
- The full database integrity check passed on the new restored backup, but the
  broader pre-existing foreign-key violations noted in
  [MIGRATION_065_INCIDENT_REVIEW.md](MIGRATION_065_INCIDENT_REVIEW.md) remain
  outside A2's scope.
