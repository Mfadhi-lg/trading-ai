"""Package the isolated A2 source changes as a conventional review patch."""

from __future__ import annotations

import difflib
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
FILES = (
    "compose.yml",
    "scrapper/cli.py",
    "scrapper/db/database.py",
    "scrapper/db/exchange_repo.py",
    "scrapper/pipeline/exchange_universe.py",
    "scrapper/pipeline/scheduler.py",
    "scrapper/tests/test_e06_scheduler.py",
    "scrapper/tests/test_migration_gate.py",
    "scrapper/db/migrations/065_exchange_source_access.sql",
)


def main() -> None:
    patch = []
    for name in FILES:
        source = ROOT / "a2-review" / name
        current = source.read_text()
        baseline = subprocess.run(
            ["git", "show", f"HEAD:{name}"], cwd=ROOT,
            capture_output=True, text=True, check=False,
        )
        is_new = baseline.returncode != 0
        before = "" if is_new else baseline.stdout
        if before == current:
            continue
        patch.append(f"diff --git a/{name} b/{name}\n")
        if is_new:
            patch.append("new file mode 100644\n")
        patch.extend(difflib.unified_diff(
            before.splitlines(keepends=True), current.splitlines(keepends=True),
            fromfile="/dev/null" if is_new else f"a/{name}",
            tofile=f"b/{name}",
        ))
    (Path(__file__).parent / "A2_REVIEW.patch").write_text("".join(patch))


if __name__ == "__main__":
    main()
