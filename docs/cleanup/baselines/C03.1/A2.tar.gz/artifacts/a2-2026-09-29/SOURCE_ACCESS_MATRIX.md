# A2 source access and entitlement matrix — 29 September 2026 IST

This records operational evidence from the consistent A0 backup and the active
checkout at `e71d1ee1`. It is **not** a license or legal-permission finding.
`UNVERIFIED` means no owner-supplied grant, terms record, contract, or API
entitlement was available to this audit. No live source request was made for A2.

| Source | Discovery | Bulk fetching | Local retention | Automated research | Evidence / current control |
|---|---|---|---|---|---|
| NSE integrated results and security masters | Operationally observed; permission UNVERIFIED | Operationally observed; permission UNVERIFIED | UNVERIFIED | UNVERIFIED | NSE result and master snapshots passed on 29 September around 05:54 UTC in [A0 source status](../a0-2026-09-29/source_error_summary.md). A public page does not grant unrestricted API use. |
| BSE `Corp_FinanceResult_ng_new` | **ACCESS_BLOCKED** for machine requests; permission UNVERIFIED | **ACCESS_BLOCKED**; entitlement/allowlisting UNVERIFIED | UNVERIFIED | UNVERIFIED | Stored scheduler responses contain HTTP 403; last accepted result snapshot was 16 September. The review patch would hold this dataset until approved access evidence is recorded. |
| BSE security master | **ACCESS_BLOCKED** for machine requests; permission UNVERIFIED | **ACCESS_BLOCKED**; entitlement/allowlisting UNVERIFIED | UNVERIFIED | UNVERIFIED | Stored HTTP 403; last accepted master snapshot was 23 September. The review patch gives it a separate access hold. |
| Issuer investor-relations sites | Per-issuer UNVERIFIED | Per-issuer UNVERIFIED | Per-issuer UNVERIFIED | Per-issuer UNVERIFIED | Existing issuer-IR recovery adapter; each host's terms and access response require review before automation. |
| Screener | Operationally observed; permission UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | A0 recorded HTTP 200 page fetches on 29 September; that establishes reachability only. |
| Data vendors, including Upstox/Trendlyne | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | No A2 vendor entitlement or retention grant supplied. The Upstox pilot records that token/retention permissions remain unverified. |
| Operator-supplied original files | Allowed only when the operator confirms source rights and provenance | Not applicable to the local import itself | UNVERIFIED per original publisher/license | UNVERIFIED per original publisher/license | Existing result-feed `--file` and manual document import paths preserve source evidence; importing bytes does not grant onward research rights. |

## Hold and controlled resume

The review patch makes the scheduler persist a BSE 403 as `source_access_blocked`, stop further
scheduled fetches for that dataset (including catch-up and revision runs), and
continues other sources. The patched status output reports `ACCESS_BLOCKED` separately
from `NEVER_REFRESHED`, `ARTIFACT_NOT_FOUND` (HTTP 404/410), and fetch errors.
It does not alter result watermarks, accepted snapshots, or company queues. The
patch has **not** been approved or deployed. The new migration was applied
automatically by a running container when the mounted working tree briefly
contained it; the source files were restored immediately afterward. See the
A2 review handoff for this deployment incident and the current release gate.

An operator should obtain BSE-approved API/feed or allowlisting information only
if the measured company/source gap warrants it. After approved machine access is
documented, record the grant, scope, date, and contact in an internal evidence
record, then run:

```text
python -m scrapper.cli exchange-scheduler --resume-access bse_financial_results --resume-evidence "approval reference and effective date"
```

Resume releases only that named dataset and makes the next normal scheduled
attempt eligible. It makes no source request itself. Repeat separately for
`bse_security_master` only if its own access is approved. Check
`exchange-scheduler --status` and the next scheduled run; another 403 restores
the hold. Do not use browser sessions, header/identity rotation, or an
unapproved endpoint as a substitute for access authorization.
