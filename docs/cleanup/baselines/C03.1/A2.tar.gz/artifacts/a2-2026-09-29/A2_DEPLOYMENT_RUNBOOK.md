# A2 deployment runbook — prepared, not authorized

**Current state:** the live local database has migration 065; the running
application is still the unpatched source with a host bind mount. No production
service restart, A2 patch application, or BSE resume is authorized by this
review. Use this runbook only after explicit deployment approval.

## Release gates before approval is requested

1. Review [MIGRATION_065_INCIDENT_REVIEW.md](MIGRATION_065_INCIDENT_REVIEW.md)
   and [PRODUCTION_COMPATIBILITY_TEST.md](PRODUCTION_COMPATIBILITY_TEST.md).
   Confirm the new backup exists at `/data/a2_post065_backup_20260929.sqlite`
   and its isolated restore and full integrity check remain available. Preserve
   the backup under the owner's retention policy; the external document corpus
   is not included.
2. Review [A2_REVIEW.patch](A2_REVIEW.patch) in an isolated checkout. Its
   `compose.yml` change must remove every source-tree mount, including manual
   profiles. `init_db()` must refuse newly visible migrations on the configured
   service database during ordinary worker work. Re-run `git apply --check` and
   the Python 3.12.14 pinned offline suite there.
3. Resolve or explicitly accept the image dependency drift: the current image
   is Python 3.12.14 but has no pytest and has three versions different from
   `scrapper/requirements.lock`. The tested isolated environment matched all
   25 lock entries. The current Dockerfile installs loose `requirements.txt`;
   an immutable release image should be built and verified with the reviewed
   dependency set before service recreation.
4. Check the live database read-only immediately before release: latest
   migration must be 065, with no unexpected pending SQL filenames or
   additional source-access events. Rehearse any new migration separately on
   a fresh copy and obtain separate production-migration approval. **Do not
   reapply 065**; it is already recorded live.

## Deployment after explicit approval

1. Build the reviewed image from an isolated, immutable checkout. Do not stage
   migration files or code edits in the currently bind-mounted host
   `scrapper/` while the old services are running. Verify the image contains
   the approved code and the expected Python/dependency versions.
2. Validate the reviewed Compose config with all profiles. Confirm no
   `/app/scrapper` bind mount and confirm `/data` remains the intended database
   volume. Recreate services only under the approved change window. Do not
   invoke `init-db --apply-migrations` for 065; its live row already exists.
   For any later approved SQL migration, use that explicit command only after
   backup and clone rehearsal. Routine workers must fail closed on pending SQL.
3. Before allowing an automatic scheduler catch-up, inspect its planned NSE
   and other source jobs against the dated access matrix. The already-held BSE
   datasets must remain suspended. If source authorization is still unknown,
   keep that job paused under the approved rollout procedure; the A2 status
   check itself makes no source request.
4. Check `exchange-scheduler --status` and structured alerts. The two BSE
   datasets should report `ACCESS_BLOCKED`; `unpublished_datasets` must not
   include them. Check that their last accepted snapshots, result watermarks
   and queued requirements have not changed merely because of the rollout.
   Confirm an unrelated source job can proceed under its own approved policy.
5. Resume **one BSE dataset at a time** only after an approved API/feed or
   allowlisting grant for that machine and use is documented. The command is
   `exchange-scheduler --resume-access DATASET --resume-evidence "approval
   reference and effective date"`. Resume records evidence and performs no
   request; the next normal permitted schedule attempts the source. A new 403
   reinstates the hold. BSE results and BSE master require separate decisions.

## Rollback and stop conditions

- Stop the rollout if the live schema differs from the verified 65-migration
  state, if the reviewed image reintroduces a host source mount, if the pinned
  tests fail, or if a status check shows a BSE source being fetched while held.
- A code rollback uses the previously approved immutable image and Compose
  configuration, not an in-place edit to the mounted source. The old code was
  tested on a post-065 copy and can read/write its legacy schedule outcomes.
- Leave migration 065 and the access-event table intact during code rollback.
  Do **not** restore the old A0 database, drop the table, or remove BLOCKED
  events automatically. Any database reversal requires a new consistent backup,
  a comparison of later writes, and separate explicit approval.
- The backup and restore files may be retained or cleaned up only under the
  owner's storage policy; this runbook does not delete them.
