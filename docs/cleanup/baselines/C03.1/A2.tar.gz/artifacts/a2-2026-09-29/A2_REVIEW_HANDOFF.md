# A2 review handoff — 29 September 2026

**Status:** implementation and offline tests complete in an isolated review copy;
application deployment awaits owner approval. [A2_REVIEW.patch](A2_REVIEW.patch)
passes `git apply --check` against the active checkout. The patch is not applied
to the mounted `scrapper/` source tree.

## Exact source changes in the patch

| File | Change |
|---|---|
| `scrapper/pipeline/exchange_universe.py` | Raise a typed BSE access-denial exception on HTTP 403 before parsing. 404/410 retain the existing dated-artifact absence path. |
| `scrapper/db/exchange_repo.py` | Admit `source_access_blocked` in the schedule ledger and add append-only BLOCKED/RESUMED access events with current/as-of hold lookup. |
| `scrapper/db/migrations/065_exchange_source_access.sql` | Expand the existing schedule outcome constraint, add one source-access event table, and backfill only BSE datasets whose last real stored fetch was a 403. No financial/queue tables are changed. |
| `scrapper/pipeline/scheduler.py` | Persist a hold before the ledger entry; suppress later rungs, catch-up and revision requests for held datasets; keep other datasets running; emit the existing structured alert; report per-dataset states and true 404/410 artifact absence separately. Resume records evidence without fetching. |
| `scrapper/cli.py` | Add `exchange-scheduler --resume-access BSE_DATASET --resume-evidence TEXT`; reject mixed resume/run modes. |
| `scrapper/tests/test_e06_scheduler.py` | Add offline fixtures for BSE 403, NSE 403, 404, 500, retry suppression, alerts, as-of status, snapshot/watermark/queue preservation, resume, and migration backfill. |
| `scrapper/db/database.py` | Prevent routine workers from applying newly visible SQL migrations to the configured service database; require an explicit migration action. Isolated test databases keep normal bootstrap behavior. |
| `scrapper/tests/test_migration_gate.py` | Prove a new SQL file cannot migrate the configured service database without explicit action. |
| `compose.yml` | Remove source-tree bind mounts from every service, including manual profiles, so approved images provide immutable running code. |

## Test evidence

- An isolated, network-disabled container using production Python **3.12.14**
  and exact versions of all **25** `scrapper/requirements.lock` dependencies
  passed **154 tests, 20 subtests** across the exchange tests plus
  `test_migration_gate.py`.
- The patched code passed a separate behavior test against an ephemeral copy of
  the new database backup, which already contains migration 065. Its production
  volume mount was read-only and no network was available. See
  [PRODUCTION_COMPATIBILITY_TEST.md](PRODUCTION_COMPATIBILITY_TEST.md).
- `git apply --check artifacts/a2-2026-09-29/A2_REVIEW.patch` passed against
  the active checkout.
- No live source request was made.

## Mounted-source migration incident

During development, `scrapper/` was discovered to be bind mounted into running
containers. Before the source files were restored, a running worker's normal
`init_db()` automatically applied migration `065_exchange_source_access.sql`
to the **live local SQLite database** at **2026-09-29 09:29:23.883230 UTC**.
A read-only live check found two backfilled BLOCKED events:
`bse_security_master` (last 403 at 05:54:05 UTC) and
`bse_financial_results` (last 403 at 05:54:07 UTC). This schema change occurred
without the requested deployment approval. The mounted application source files
were immediately restored to their pre-A2 state; no worker was restarted, no
operator resume command was run, and no live source was queried. The old code
does not use the new access-event table; the BSE retry suppression is **not yet
active** in production. The migration expands an outcome constraint and adds a
table; it preserves existing schedule rows.

## Remaining access limitations

The BSE machine route still has stored HTTP 403s and no confirmed API/feed or
allowlisting entitlement. NSE reachability is observed, but its usage rights
are unverified. Issuer IR, Screener, vendor, and original-file rights are
similarly unverified in [SOURCE_ACCESS_MATRIX.md](SOURCE_ACCESS_MATRIX.md).
The [affected-company report](AFFECTED_COMPANY_REPORT.md) measures BSE source
exposure using registry links, filing provenance, enqueue decisions and accepted
versions; it does not attribute missing financial data to the 403.

## Release and rollback

Do not apply the patch or restart services without owner approval. Before a
release, review the already-applied live migration against the A0 backup and
confirm the active checkout is still compatible; then apply the patch and run
the pinned offline tests. On deployment, check `exchange-scheduler --status`
and confirm the two BSE datasets show `ACCESS_BLOCKED` with no new requests.

If code deployment must be rolled back, reverse the patch (`git apply -R
artifacts/a2-2026-09-29/A2_REVIEW.patch`) and restart the affected service
only under the normal change procedure. The old code is compatible with the
expanded schedule table and ignores access events. **Do not drop the new table
or restore the 10 GB A0 backup automatically:** either action can lose later
schedule history. A database reversal requires a fresh consistent backup,
comparison of post-migration writes, and a separately approved migration plan.
