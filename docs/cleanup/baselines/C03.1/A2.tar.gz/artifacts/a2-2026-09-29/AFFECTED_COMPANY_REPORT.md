# A2 affected-company source exposure — 29 September 2026

Input: consistent A0 SQLite backup `trading-ai-a0-backup-20260929.sqlite`, taken around 14:07 IST.
The export is read-only. BSE financial-results HTTP 403 was recorded at 05:54:07 UTC.

| Population from current present exchange registry links | Count |
|---|---:|
| BSE-linked registry companies (export denominator) | 5,043 |
| BSE route without a current NSE link | 2,588 |
| BSE route with a current NSE link | 2,455 |
| At least one stored BSE Q1 FY27 standalone filing | 4,134 |
| At least one stored NSE Q1 FY27 standalone filing | 2,156 |
| At least one stored BSE filing enqueue decision in Q1/Q2 | 4,128 |
| Accepted Q1 FY27 standalone page version | 2,002 |

[affected_companies.csv](affected_companies.csv) lists each BSE-linked registry entity,
its exchange routes, stored source-specific standalone filing counts, BSE enqueue
decisions, and accepted standalone page flags. A BSE-only link identifies a
direct *source-discovery exposure* while the BSE feed is blocked. A current NSE
link gives a possible alternate route; it does not prove an equivalent filing was
published there. The BSE result endpoint is a bulk feed, so no particular
company request failed with 403. **No row is labelled as missing financial data
because of this access failure.** Q2 FY27 had not ended at the backup time, so
zero Q2 accepted results would not be a publication failure.

Mapping uses ISIN where present, then the current exchange key. 396
Q1/Q2 filing rows could not be mapped to a current registry company by those
keys and are excluded from the per-company filing counts. Source permission and
the completeness of each accepted financial value remain unverified.
