"""Offline A2 source-exposure inventory from a consistent SQLite backup.

Usage: python build_affected_company_report.py BACKUP_DB OUTPUT_DIR
This opens the source in SQLite read-only mode and never imports application DB code.
"""

from __future__ import annotations

import csv
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path


def main(db_path: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(f"file:{db_path.resolve()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    registry = {r["registry_company_id"]: dict(r) for r in conn.execute(
        "SELECT registry_company_id,isin,canonical_name_raw,company_id "
        "FROM exchange_company_registry"
    )}
    by_isin = {r["isin"]: rid for rid, r in registry.items()}
    exchanges = defaultdict(set)
    by_key = {}
    for row in conn.execute(
        """SELECT link.registry_company_id, security.exchange, security.exchange_key
           FROM exchange_company_links AS link
           JOIN exchange_securities AS security USING (exchange_security_id)
           WHERE link.is_current=1 AND security.is_present=1"""
    ):
        rid = row["registry_company_id"]
        exchanges[rid].add(row["exchange"])
        by_key[(row["exchange"], row["exchange_key"])] = rid

    filing_counts = defaultdict(Counter)
    filing_ids = {}
    unresolved_filings = 0
    for row in conn.execute(
        """SELECT filing_id,exchange,exchange_key,isin,result_period,reporting_scope
           FROM exchange_result_filings
           WHERE result_period IN ('2026-06','2026-09')"""
    ):
        rid = by_isin.get(row["isin"]) if row["isin"] else None
        rid = rid or by_key.get((row["exchange"], row["exchange_key"]))
        if rid is None:
            unresolved_filings += 1
            continue
        filing_ids[row["filing_id"]] = rid
        filing_counts[rid][f"{row['exchange']}_{row['result_period']}_{row['reporting_scope']}"] += 1

    queue_counts = defaultdict(Counter)
    for row in conn.execute(
        """SELECT enqueue.registry_company_id, enqueue.filing_id, filing.exchange,
                  enqueue.decision, queue.status AS queue_status
           FROM exchange_screener_enqueues AS enqueue
           JOIN exchange_result_filings AS filing USING (filing_id)
           LEFT JOIN screener_company_queue AS queue ON queue.queue_item_id=enqueue.queue_item_id
           WHERE filing.result_period IN ('2026-06','2026-09')"""
    ):
        rid = row["registry_company_id"] or filing_ids.get(row["filing_id"])
        if rid is None:
            continue
        queue_counts[rid][f"{row['exchange']}_decisions"] += 1
        if row["queue_status"] and row["queue_status"] not in (
            "accepted", "skipped_already_accepted"
        ):
            queue_counts[rid][f"{row['exchange']}_not_accepted_queue"] += 1

    accepted = defaultdict(set)
    for row in conn.execute(
        """SELECT DISTINCT company_id,resolved_source_period
           FROM accepted_page_versions
           WHERE reporting_scope='standalone'
             AND resolved_source_period IN ('2026-06','2026-09')"""
    ):
        accepted[row["company_id"]].add(row["resolved_source_period"])

    fields = [
        "registry_company_id", "company_id", "isin", "company_name",
        "current_exchange_links", "source_exposure", "bse_q1_standalone_filings",
        "nse_q1_standalone_filings", "bse_q2_standalone_filings",
        "nse_q2_standalone_filings", "bse_enqueue_decisions_q1_q2",
        "bse_not_accepted_queues_q1_q2", "accepted_q1_standalone",
        "accepted_q2_standalone", "financial_gap_inference",
    ]
    output = []
    for rid, record in sorted(registry.items()):
        linked = exchanges[rid]
        if "BSE" not in linked:
            continue
        cohort = (
            "DIRECT_BSE_ROUTE_NO_NSE_LINK" if "NSE" not in linked
            else "BSE_ROUTE_WITH_NSE_LINK"
        )
        company_id = record["company_id"]
        counts = filing_counts[rid]
        queues = queue_counts[rid]
        output.append({
            "registry_company_id": rid,
            "company_id": company_id or "",
            "isin": record["isin"],
            "company_name": record["canonical_name_raw"],
            "current_exchange_links": ",".join(sorted(linked)),
            "source_exposure": cohort,
            "bse_q1_standalone_filings": counts["BSE_2026-06_standalone"],
            "nse_q1_standalone_filings": counts["NSE_2026-06_standalone"],
            "bse_q2_standalone_filings": counts["BSE_2026-09_standalone"],
            "nse_q2_standalone_filings": counts["NSE_2026-09_standalone"],
            "bse_enqueue_decisions_q1_q2": queues["BSE_decisions"],
            "bse_not_accepted_queues_q1_q2": queues["BSE_not_accepted_queue"],
            "accepted_q1_standalone": int("2026-06" in accepted[company_id]),
            "accepted_q2_standalone": int("2026-09" in accepted[company_id]),
            "financial_gap_inference": "NOT_INFERRED_FROM_ACCESS_FAILURE",
        })
    conn.close()
    with (output_dir / "affected_companies.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output)
    cohorts = Counter(row["source_exposure"] for row in output)
    bse_q1 = sum(int(row["bse_q1_standalone_filings"] > 0) for row in output)
    nse_q1 = sum(int(row["nse_q1_standalone_filings"] > 0) for row in output)
    bse_queue = sum(int(row["bse_enqueue_decisions_q1_q2"] > 0) for row in output)
    q1_accepted = sum(row["accepted_q1_standalone"] for row in output)
    report = f"""# A2 affected-company source exposure — 29 September 2026

Input: consistent A0 SQLite backup `{db_path.name}`, taken around 14:07 IST.
The export is read-only. BSE financial-results HTTP 403 was recorded at 05:54:07 UTC.

| Population from current present exchange registry links | Count |
|---|---:|
| BSE-linked registry companies (export denominator) | {len(output):,} |
| BSE route without a current NSE link | {cohorts['DIRECT_BSE_ROUTE_NO_NSE_LINK']:,} |
| BSE route with a current NSE link | {cohorts['BSE_ROUTE_WITH_NSE_LINK']:,} |
| At least one stored BSE Q1 FY27 standalone filing | {bse_q1:,} |
| At least one stored NSE Q1 FY27 standalone filing | {nse_q1:,} |
| At least one stored BSE filing enqueue decision in Q1/Q2 | {bse_queue:,} |
| Accepted Q1 FY27 standalone page version | {q1_accepted:,} |

[affected_companies.csv](affected_companies.csv) lists each BSE-linked registry entity,
its exchange routes, stored source-specific standalone filing counts, BSE enqueue
decisions, and accepted standalone page flags. A BSE-only link identifies a
direct *source-discovery exposure* while the BSE feed is blocked. A current NSE
link gives a possible alternate route; it does not prove an equivalent filing was
published there. The BSE result endpoint is a bulk feed, so no particular
company request failed with 403. **No row is labelled as missing financial data
because of this access failure.** Q2 FY27 had not ended at the backup time, so
zero Q2 accepted results would not be a publication failure.

Mapping uses ISIN where present, then the current exchange key. {unresolved_filings:,}
Q1/Q2 filing rows could not be mapped to a current registry company by those
keys and are excluded from the per-company filing counts. Source permission and
the completeness of each accepted financial value remain unverified.
"""
    (output_dir / "AFFECTED_COMPANY_REPORT.md").write_text(report)
    print(f"{len(output)} BSE-linked registry companies; {unresolved_filings} unresolved filings")


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
