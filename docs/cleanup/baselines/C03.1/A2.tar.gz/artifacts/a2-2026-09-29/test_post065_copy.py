"""Run patched A2 behavior against an ephemeral copy of a post-065 backup.

The supplied source path is a read-only mounted backup, not the live database.
All writes go to /tmp inside a network-disabled, disposable container.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sqlite3
import sys
from pathlib import Path
from unittest import mock

from scrapper.core.http import FetchResponse
from scrapper.pipeline import scheduler


BACKUP = Path(sys.argv[1])
COPY = Path("/tmp/a2-post065-compat.sqlite")
assert BACKUP.name == "a2_post065_compat_test_20260929.sqlite"
assert str(BACKUP).startswith("/source/")
assert not COPY.exists()
shutil.copyfile(BACKUP, COPY)


def rows(sql: str, params: tuple = ()) -> list[tuple]:
    conn = sqlite3.connect(f"file:{COPY}?mode=ro", uri=True)
    try:
        return conn.execute(sql, params).fetchall()
    finally:
        conn.close()


def baseline() -> dict:
    return {
        "migration_count": rows("SELECT COUNT(*) FROM schema_migrations")[0][0],
        "accepted_versions": rows("SELECT COUNT(*) FROM accepted_page_versions")[0][0],
        "snapshots": rows("SELECT COUNT(*) FROM exchange_source_snapshots")[0][0],
        "watermarks": rows(
            "SELECT exchange,dataset,last_broadcast_at_utc,last_snapshot_id "
            "FROM exchange_result_watermarks ORDER BY exchange,dataset"
        ),
        "company_queue": rows("SELECT COUNT(*) FROM screener_company_queue")[0][0],
    }


before = baseline()
assert before["migration_count"] == 65
assert rows(
    "SELECT dataset,action FROM exchange_source_access_events ORDER BY dataset"
) == [
    ("bse_financial_results", "BLOCKED"),
    ("bse_security_master", "BLOCKED"),
]

calls: list[tuple[str, int]] = []
next_status = {"NSE": 404, "BSE": 403}


def fake_fetch(url: str, exchange: str) -> FetchResponse:
    status = next_status[exchange]
    calls.append((exchange, status))
    return FetchResponse(
        requested_url=url, final_url=url, status_code=status, content=b"",
        content_type="text/plain", encoding=None, etag=None,
        last_modified=None, auth_mode="test_fixture",
        fetch_status="not_found" if status == 404 else
                     "rejected" if status == 403 else "error",
    )


def now() -> str:
    return "2026-09-30T14:00:00+00:00"


day = "2026-09-30"
first = scheduler.run_attempt(
    attempt=1, scheduled_for=day,
    datasets=("bse_financial_results", "bse_security_master", "nse_financial_results"),
    db_path=COPY, snapshot_root=Path("/tmp/a2-snapshots"),
    now_utc=now, fetcher=fake_fetch,
)
assert first["access_blocked_datasets"] == [
    "bse_financial_results", "bse_security_master"
]
assert first["retry_scheduled"] is True  # NSE 404 remains retryable.
assert calls == [("NSE", 404), ("NSE", 404)]  # primary and revision sweep
status = scheduler.day_status(day, db_path=COPY, now_utc=now)
assert status["dataset_states"]["bse_financial_results"] == "ACCESS_BLOCKED"
assert status["dataset_states"]["bse_security_master"] == "ACCESS_BLOCKED"
assert status["dataset_states"]["nse_financial_results"] == "ARTIFACT_NOT_FOUND"
assert status["dataset_states"]["nse_equity_master"] == "NOT_CHECKED_TODAY"
assert status["unpublished_datasets"] == ["nse_financial_results"]

next_status["NSE"] = 500
second = scheduler.run_attempt(
    attempt=2, scheduled_for=day,
    datasets=("bse_financial_results", "bse_security_master", "nse_financial_results"),
    db_path=COPY, snapshot_root=Path("/tmp/a2-snapshots"),
    now_utc=now, fetcher=fake_fetch,
)
assert second["retry_scheduled"] is True
assert calls == [("NSE", 404), ("NSE", 404), ("NSE", 500)]
status = scheduler.day_status(day, db_path=COPY, now_utc=now)
assert status["dataset_states"]["nse_financial_results"] == "FETCH_FAILED"
assert "nse_financial_results" not in status["unpublished_datasets"]

stderr = io.StringIO()
with mock.patch.object(
    scheduler, "scheduled_datasets", return_value=("bse_financial_results",)
), contextlib.redirect_stderr(stderr):
    alerted = scheduler.run_scheduler(
        once=True, db_path=COPY, snapshot_root=Path("/tmp/a2-snapshots"),
        now_utc=now, fetcher=fake_fetch,
    )
assert alerted["status"] == "access_blocked"
assert json.loads(stderr.getvalue())["access_blocked_datasets"] == [
    "bse_financial_results"
]
assert calls == [("NSE", 404), ("NSE", 404), ("NSE", 500)]

resumed = scheduler.resume_source_access(
    "bse_financial_results", "ISOLATED TEST ONLY, NO ENTITLEMENT CLAIM",
    db_path=COPY, now_utc=now,
)
assert resumed["access_state"] == "RESUMED"
assert calls == [("NSE", 404), ("NSE", 404), ("NSE", 500)]
next_status["BSE"] = 403
third = scheduler.run_attempt(
    attempt=3, scheduled_for=day,
    datasets=("bse_financial_results", "bse_security_master"),
    db_path=COPY, snapshot_root=Path("/tmp/a2-snapshots"),
    now_utc=now, fetcher=fake_fetch,
)
assert third["retry_scheduled"] is False
assert calls == [("NSE", 404), ("NSE", 404), ("NSE", 500), ("BSE", 403)]
assert rows(
    "SELECT action FROM exchange_source_access_events "
    "WHERE dataset='bse_financial_results' ORDER BY event_id"
) == [("BLOCKED",), ("RESUMED",), ("BLOCKED",)]
assert not rows(
    "SELECT 1 FROM exchange_schedule_runs "
    "WHERE dataset LIKE 'bse_%' AND outcome='not_published' AND scheduled_for=?",
    (day,),
)

after = baseline()
assert after == before, (before, after)
print(json.dumps({
    "result": "PASS", "python": sys.version.split()[0],
    "migration_count": before["migration_count"],
    "initial_blocked_events": 2,
    "fixture_calls": calls,
    "accepted_versions_preserved": before["accepted_versions"],
    "snapshots_preserved": before["snapshots"],
    "watermarks_preserved": len(before["watermarks"]),
    "company_queue_rows_preserved": before["company_queue"],
    "source_volume_mount": "read_only",
    "network": "none",
}, sort_keys=True))
