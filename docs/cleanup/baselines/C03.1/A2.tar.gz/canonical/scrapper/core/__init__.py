"""Shared scraper primitives."""
