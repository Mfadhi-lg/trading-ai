"""SQLite connection and ordered migration application."""
import fcntl
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from ..config import DB_PATH, MIGRATIONS_PATH, ensure_dirs


_IN_PROCESS_MIGRATION_LOCK = threading.Lock()


@contextmanager
def _migration_lock(conn: sqlite3.Connection):
    """Serialize migration discovery and application across worker processes."""

    database_path = str(
        conn.execute("PRAGMA database_list").fetchone()[2] or ""
    )
    if not database_path:
        with _IN_PROCESS_MIGRATION_LOCK:
            yield
        return
    lock_path = Path(database_path + ".migrate.lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA busy_timeout=5000;")
    conn.row_factory = sqlite3.Row
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    with _migration_lock(conn):
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations "
            "(version TEXT PRIMARY KEY, applied_at_utc TEXT NOT NULL)"
        )
        applied = {
            row["version"]
            for row in conn.execute("SELECT version FROM schema_migrations")
        }
        for migration in sorted(Path(MIGRATIONS_PATH).glob("*.sql")):
            if migration.name in applied:
                continue
            with conn:
                conn.executescript(migration.read_text(encoding="utf-8"))
                conn.execute(
                    "INSERT INTO schema_migrations(version, applied_at_utc) VALUES (?, ?)",
                    (migration.name, datetime.now(timezone.utc).isoformat()),
                )
